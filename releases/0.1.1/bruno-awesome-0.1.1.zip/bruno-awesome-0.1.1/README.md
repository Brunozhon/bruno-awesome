# Bruno Awesome

<i style="color: gray">"That bruno is really awesome"</i>

Bruno Awesome is a (dynamic) icon set with everday animated icons.
